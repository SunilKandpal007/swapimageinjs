function showText(){
    document.getElementById("p1").innerHTML="Hello, Sunil";
    document.getElementById("p1").style.color = "red";
    document.getElementById("p1").style.fontStyle = "underline";
    document.getElementById("p1").style.backgroundColor = "cyan";
    document.getElementById("p1").style.margin = "auto";
    document.getElementById("p1").style.padding = "10px";
    document.getElementById("p1").style.width = "700px";
    document.getElementById("p1").style.fontSize = "15px";
    document.getElementById("p1").style.textAlign = "center";

}

function showmyDate(){
    document.getElementById("p1").innerHTML = Date();
}

function showImg() {
    document.getElementById("myImg1").src = "img/flamingo.jpg";
}

